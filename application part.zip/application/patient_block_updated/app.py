import base64
from flask import Flask,url_for,request,render_template,session
from flask_mail import Mail, Message
import sqlite3
import blockchain1
from blockchain1 import BlockChain,Block
from random import randint
from base64 import b64encode
import os
app=Flask(__name__)
mail=Mail(app)
app.secret_key="Rudy"

app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'testcasep@gmail.com'
app.config['MAIL_PASSWORD'] = 'project2021'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
app.config['UPLOAD_DIR'] = 'static/Uploads'
mail = Mail(app)

def random_with_N_digits(n):
    range_start = 10**(n-1)
    range_end = (10**n)-1
    return randint(range_start, range_end)

@app.route('/' ,methods=["GET","POST"])
def login():
    username=None
    password=None
    err="Invalid username and password"
    if request.method=='POST':
        session['username']=request.form['uname']
        username=request.form['uname']
        password=request.form['pwd']
        conn = sqlite3.connect("reg1.db")
        r=conn.cursor()
        r.execute("select name,pwd from reg where name=? and pwd=?",(username,password))
        rows=r.fetchall()

        if len(rows)!=0:
            for i in rows:
                if i[0]==username and i[1]==password:
                    return render_template('user.html',username=username)
                else:
                    return render_template('login.html',err=err)
        else:
            return render_template('login.html',err=err)
    return render_template('login.html')
@app.route('/user')
def user():
    return render_template('user.html')

@app.route('/doc_home', methods=["GET","POST"])
def doc_home():
    dname=None
    dpwd=None
    if request.method=='POST':
        dname=request.form['dname']
        dpwd=request.form['dpwd']
        conn=sqlite3.connect("doc_log.db")
        c = conn.cursor()
        c.execute("select username,password from doc_reg1 where username=? and password=?",(dname,dpwd))
        rows=c.fetchall()
        if len(rows)!=0:
            for i in rows:
                if i[0]==dname and i[1]==dpwd:
                    return render_template('doc_page.html')
                else:
                    return render_template('doc.html')
        else:
            return render_template('doc.html')

    return render_template('doc.html')
    
@app.route('/reg', methods=["GET","POST"])
def reg():
    uname=None
    pwd=None
    cpwd=None
    ema=None
    msg="Register successfully"
    if request.method=='POST':
        uname=request.form['txt']
        pwd=request.form['passw']
        cpwd=request.form['cpassw']
        ema=request.form['em']
        import sqlite3
        table_name = 'reg'
        conn = sqlite3.connect("reg1.db")
        c = conn.cursor()
        c.execute('create table if not exists ' + table_name + ' (name varchar(50),pwd varchar(50),cpwd varchar(50),email varchar(50))')
        c.execute('insert into '+table_name+'  values (?,?,?,?)',(uname,pwd,cpwd,ema))
        conn.commit()
        conn.close()
        return render_template('registraion.html',msg=msg)
    return render_template('registraion.html')

@app.route('/health_record',methods=["GET","POST"])
def health_record():
    if request.method=='GET':
        conn=sqlite3.connect("block_chain.db")
        c=conn.cursor()
        c.execute("select * from block_chain where name=?",(session['username'],))
        rows=c.fetchall()
        for i in rows:
            print(i)

    return render_template('info.html',rows=rows)

@app.route('/proupdate')
def proupdate():
    conn = sqlite3.connect("reg1.db")
    r=conn.cursor()
    r.execute("select name,pwd from reg ")
    rows=r.fetchall()
    print(rows)
    return render_template('user.html',rows=rows)

@app.route('/addmyrecord',methods=["GET","POST"])
def addmyrecord():
    rname=None
    rplace1=None
    ramount=None
    nonce=None
    tstamp=None
    final_li=[]
    
    if request.method=='POST':
        nonce=request.form['nonce']
        tstamp=request.form['tstamp']
        rname=request.form['name']
        # rplace=request.form['place']
        rplace1 = request.files["image"]
        rplace1.save(os.path.join(app.config['UPLOAD_DIR'],rplace1.filename))
        # rplace = base64.b64encode(rplace1).decode('utf-8')
        # base64.b64decode
        ramount=request.form['amount']
        location=request.form['location']
        sqtft=request.form['sqft']
        u=[]
        u.append(nonce)
        u.append(tstamp)
        u.append(rname)
        u.append(ramount)
        u.append(rplace1.filename)
        u.append(location)
        u.append(sqtft)
        conn = sqlite3.connect("block_chain.db")
        g = conn.cursor()
        g.execute("select nonce,tstamp,name,place,amount,location,sqtft from block_chain")
        rows=g.fetchall()
# print(rows)
        li=[]
        for i in rows:
            li.append(i)
        li.append(u)
        
        table_name="block_chain"
        conn = sqlite3.connect("block_chain.db")
        c = conn.cursor()
        c.execute('create table if not exists ' + table_name + ' (nonce varchar(50),tstamp varchar(50),name varchar(50),place varchar(50),amount varchar(50),location varchar(50),sqtft varchar(50),phash varchar(50),hash varchar(50))')
        for i in range(len(li)):
            if li[i] not in final_li:
                final_li.append(li[i])
        print(final_li)
        c.execute("delete from block_chain")
        print(final_li[0])
        osa=BlockChain()
        for i in range(len(final_li)):
            osa.addBlock(Block(final_li[i][0],final_li[i][1],final_li[i][2],final_li[i][4],final_li[i][3],final_li[i][5],final_li[i][6]))
        for b in osa.chain:
            c.execute('insert into '+table_name+'  values (?,?,?,?,?,?,?,?,?)',(b.nonce,b.tstamp,b.name,b.place,b.amount,b.location,b.sqtft,b.prevhash,b.hash))
        conn.commit()
        conn.close()
    return render_template("add.html")



@app.route('/patient_info',methods=["GET","POST"])
def patient_info():
    ckotp=None
    nameli=[]
    if request.method=='POST':
        ckotp=request.form['otp']
        conn=sqlite3.connect("keys.db")
        ch=conn.cursor()
        ch.execute("select name from keys where otp=?",(ckotp,))
        rows=ch.fetchall()
        for i in rows:
            nameli.append(i)
            print(i)
        conn=sqlite3.connect("block_chain.db")
        chk=conn.cursor()
        chk.execute("select nonce,tstamp,name,place,amount,phash,hash from block_chain where name=?",(nameli[0]))
        lii=chk.fetchall()
        return render_template('info.html',lii=lii)

    return render_template('doc_page.html')


@app.route('/changepassword',methods=["GET","POST"])
def changepassword():
    emailid=None
    li=[]
    if request.method=='POST':
        emailid=request.form['em']
        conn=sqlite3.connect("reg1.db")
        c = conn.cursor()
        c.execute("select name,pwd from reg where email=?",(emailid,))
        rows=c.fetchall()
        for i in rows:
            li.append(i)
        msg = Message('Patient OTP', sender = 'testcasep@gmail.com', recipients =[emailid])
        msg.body = "username: "+str(li[0][0])+" "+"Password: "+str(li[0][1])
        mail.send(msg)
    return render_template('pwd.html')


if __name__=='__main__':
    app.run(debug=True)