import hashlib
import json
from base64 import b64encode

class Block():
    def __init__(self,nonce,tstamp,name,place,amount,location,sqtft,prevhash=''):
        self.nonce=nonce
        self.tstamp=tstamp
        self.name=name
        self.place=place
        self.amount=amount
        self.location=location
        self.sqtft=sqtft
        self.prevhash=prevhash
        self.hash=self.calcHash()

    def calcHash(self):
        block_string=json.dumps({"nonce":self.nonce,"tstamp":self.tstamp,"name":self.name,"place":self.place,"amount":self.amount,"location":self.location,"sqtft":self.sqtft,"prevhash":self.prevhash},sort_keys=True).encode()
        return hashlib.sha256(block_string).hexdigest()

    def __str__(self):
        string="nonce: "+str(self.nonce)+"\n"
        string+="tstamp: "+str(self.tstamp)+"\n"
        string+="name: "+str(self.name)+"\n"
        string+="location"+str(self.place)+"\n"
        string+="sqtft"+str(self.amount)+"\n"
        string+="prevhash: "+str(self.prevhash)+"\n"
        string+="hash: "+str(self.hash)+"\n"
        return string
##    def printHashes(self):
##        print("prevhash",self.prevhash)
##        print("hash",self.hash)

##bblock=Block(1,"01/02/2019",100)
##bblock.printHashes()

class BlockChain():
    def __init__(self):
        self.chain=[self.generateGenesisBlock(),]
    def generateGenesisBlock(self):
        return Block(0,"01/01/2019","gensis name","gensis reason","Gensis Block","10000","Tambaram")
    def getLastBlock(self):
        return self.chain[-1]
    def addBlock(self,newBlock):
        newBlock.prevhash=self.getLastBlock().hash
        newBlock.hash=newBlock.calcHash()
        self.chain.append(newBlock)

    @staticmethod
    def is_valid_block(block,previous_block):
        if previous_block.index+1!=block.index:
            return False
        elif previous_block.get_block_hash!=block.previous_block:
            return False

        elif block.timestamp <= previous_block.timestamp:
            return False

        return True


    @staticmethod
    def create_proof_of_work(previous_proof):
        """
        Generate "Proof Of Work"
        A very simple `Proof of Work` Algorithm -
            - Find a number such that, sum of the number and previous POW number is divisible by 7
        """
        proof = previous_proof + 1
        while not BlockChain.is_valid_proof(proof, previous_proof):
            proof += 1

        return proof

    @staticmethod
    def is_valid_proof(proof, previous_proof):
        return (proof + previous_proof) % 7 == 0


    @property
    def get_last_block(self):
        return self.chain[-1]

    def is_valid_chain(self):
        """
        Check if given blockchain is valid
        """
        previous_block = self.chain[0]
        current_index = 1

        while current_index < len(self.chain):

            block = self.chain[current_index]

            if not self.is_valid_block(block, previous_block):
                return False

            previous_block = block
            current_index += 1

        return True


