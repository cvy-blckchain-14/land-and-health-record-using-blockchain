import sqlite3
from blockchain1 import BlockChain,Block

conn = sqlite3.connect(r"C:\Users\saran\Desktop\Flask_folder\patient_block_try\block_chain.db")
r=conn.cursor()
r.execute("select nonce,tstamp,name,reason,detail from block_chain ")
rows=r.fetchall()
# print(rows)
li=[]
li1=[]
for i in rows:
    li.append(i)

li1.append("3")
li1.append("2019-10-10")
li1.append("akhil")
li1.append("cold")
li1.append("ice water")
li.append(li1)
print(li)
print(type(li))

# osa=BlockChain()
# for i in range(len(li)):
#     for j in range(1):
#         osa.addBlock(Block(li[i][0],li[i][1],li[i][2],li[i][3],li[i][4]))

# for b in osa.chain:
#     print(b.nonce)
#     print(b.tstamp)
#     print(b.name)
#     print(b.reason)
#     print(b.detail)
#     print(b.prevhash)
#     print(b.hash)
