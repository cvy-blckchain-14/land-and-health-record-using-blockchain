# ipfs_file_upload
git clone https://github.com/rohithseetha/ipfs_file_upload.git

#After cloning execute the following commands to launch the server

npm install

node app.js
